const express = require("express");
const path = require("path");
const app = express();
const server = require("http").createServer(app);
const bcrypt = require("bcrypt")
const io = require("socket.io")(server);
const publicfold=path.join(__dirname,'/public');
app.use(express.static(__dirname + '/public'));
var bodyParser = require("body-parser")
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}))
const session = require("express-session");

app.use(
  //registers a session middleware with the Express application. 
  //This middleware will store session data in memory or a persistent store, such as a database.
  session({
    //The secret is used to encrypt the session data.
    secret: "your-secret-key",
    //The resave specifies whether the session data should be saved to the persistent store after every request.
    resave: false,
    //The saveUninitialized specifies whether the session data should be saved to the persistent store even if it has not been modified.
    saveUninitialized: true,
  })
);



// imports the User and Message classes from the DB.js file.
const { User, Message } = require("./public/DB");
// Socket.IO event listener It will listen for two events connection.
io.on("connection", function (socket) {
  // Socket.IO event listener It will listen for event newuser.
	socket.on("newuser", function (username) {
    //emit an update event to all other connected users. 
    //The update event will contain the username of the new user who joined the conversation.
	  socket.broadcast.emit("update", username + " joined the conversation");
	});
  // Socket.IO event listener It will listen for event exituser.
	socket.on("exituser", function (username) {
    //emit an update event to all other connected users. 
    //The update event will contain the username of the user who left the conversation.
	  socket.broadcast.emit("update", username + " left the conversation");
	});
	
  // Socket.IO event listener It will listen for event chat.
	socket.on("chat", function (message) {

	  //socket.broadcast object emit a chat event to all other connected users. 
    //The chat event will contain the chat message that was sent by the user.
		socket.broadcast.emit("chat", message);

		// Create a new Message document
		const newMessage = new Message({
      //the user who send the message
		  user: message.username,
      //the content of the message
		  msgs: message.text
		});

		console.log("on chat")
		console.log(message)
		console.log(newMessage)

		
  
		try {
			// Save the new Message document
			newMessage.save();
		  } catch (error) {////catches any errors that occur while Saveing the new Message.
        //logs the error to the console.
			  console.error("Error saving message:", error);
		  }
	  });
	});

// Routes
//render the index.html file when a user visits the /public route. 
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});
//send the register.html file to the client when the /register URL is requested.
app.get("/register", (req, res) => {
  res.sendFile(path.join(publicfold, "register.html"));
});
//handle POST requests to the /register route.
app.post("/register", async (req, res) => {
  try {
    //get the username and password from the request body.
    const { username, password } = req.body;

    // Check if the username is already taken
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      //If the user exists, the code returns a 409 Conflict status code and the message "Username already taken".
      return res.status(409).send("Username already taken");
    }

    // hashes the password using the bcrypt algorithm with a cost factor of 10.
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user with username and hashedPassword
    const newUser = new User({
      username,
      password: hashedPassword,
    });

    // Save the user to the database
    await newUser.save();
    //returns a 201 Created status code and the message "User registered successfully".
    res.status(201).send("User registered successfully");
  } catch (error) {//catches any errors that occur while registering a user.
    //logs the error to the console.
    console.error("Error registering user:", error);
    //sends an Internal Server Error response to the client.
    res.status(500).send("Internal Server Error");
  }
});
//handle POST requests to the /login route.
app.post("/login", async (req, res) => {
  try {
    //get the username and password from the request body.
    const { username, password } = req.body;

    // Check if the user exists
    const user = await User.findOne({ username });
    if (!user) {//checks if the user object is not defined. 
      //returns a 401 Unauthorized status code and the message "Invalid credentials".
      return res.status(401).send("Invalid credentials");
    }

    // compare the password entered by the user to the hashed password stored in the database.
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {//if dosen't match 
      //returns a 401 Unauthorized status code and the message "Invalid credentials".
      return res.status(401).send("Invalid credentials");
    }

    // Set user session
    req.session.user = {
      username: user.username
    };

    
  } catch (error) {//catches any errors that occur while logging in.
    //logs the error to the console.
    console.error("Error logging in:", error);
    //sends an Internal Server Error response to the client.
    res.status(500).send("Internal Server Error");
  }
});
//route handler for the /protected route.
app.get("/protected", (req, res) => {
  // Check if user is logged in
  if (!req.session.user) {
    //returns a 401 Unauthorized status code and the message "Unauthorized".
    return res.status(401).send("Unauthorized");
  }
  //else sends the message "Protected route" to the client.
  res.send("Protected route");
});


	  
//starts the Express server on port 5000.
server.listen(5000, () => {
  //logs a message to the console when the server starts.
  console.log("App is running on Port 5000");
});
