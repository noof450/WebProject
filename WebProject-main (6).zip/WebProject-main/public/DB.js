const mongoose = require("mongoose");
//the url of the database
const url = "mongodb+srv://Webproject:Qf1AfnfJQZ2DiVV3@cluster0.qqyaoiz.mongodb.net/?retryWrites=true&w=majority";
//connects to MongoDB and logs a message if the connection is successful or an error message if the connection fails.
mongoose.connect(url)//mongoose.connect() method returns a promise
  .then(() => {//execute a function when the promise is resolved.
    console.log("Connected to MongoDB");// log a message to the console that the connection is successful.
  })
  .catch((error) => {//xecute a function when the promise is rejected.
    console.error("Error connecting to MongoDB:", error);//log an error message to the console.
  });

//constructor creates a new schema object.
const usersSchema = new mongoose.Schema({
  //The schema defines two fields: username and password.
  username: {
    type: String
  },
  password: {
    type: String
  }
});

//Creates a model for the users collection. 
//The model is used to interact with the users collection in MongoDB.
const User = mongoose.model('User', usersSchema);

//reates a schema for a messages collection in MongoDB.
const messageSchema = new mongoose.Schema({
  //The schema defines three fields: user, msgs, and timestamp. 
  user: {
    type: String
  },
  msgs:{ 
    type: String},
  timestamp: {
    type: Date,
    default: Date.now
  }
});
//creates a model for the messages collection. 
//The model is used to interact with the messages collection in MongoDB.
const Message = mongoose.model("Message", messageSchema);

//exports the User and Message models. 
//This allows other modules to import and use the models.
module.exports = {
  User: User,
  Message: Message
};
